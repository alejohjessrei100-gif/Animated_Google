// ENGINE kit: Caribbean Cup 1994 toon football stadium (pitch, goals, live scoreboard, bleachers, palms, soccer ball, story boards).
import React, {useMemo} from 'react';
import * as THREE from 'three';
import {INK} from '../../chars/charparts';
import {LOOK_RAMP} from '../../look/look';

export type ScoreState = {
  bar: number;
  grn: number;
  clock: string;
  banner: string;
  highlight?: boolean;
};

export type BallState = {
  p: [number, number, number];
  spin?: number;
  scale?: number;
};

export type StoryBoards = {
  ruleboard?: {p: [number, number, number]; ry?: number; scrapped?: boolean; scale?: number};
  ticket?: {p: [number, number, number]; ry?: number; scale?: number};
};

function makeCanvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D, w: number, h: number) => void) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d')!;
  draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}

/** Striped toon grass + crisp white football pitch markings */
function usePitchTex() {
  return useMemo(
    () =>
      makeCanvasTex(1024, 576, (g, w, h) => {
        const stripes = 12;
        for (let i = 0; i < stripes; i++) {
          g.fillStyle = i % 2 === 0 ? '#3d8f52' : '#469e5c';
          g.fillRect((i * w) / stripes, 0, w / stripes + 1, h);
        }
        g.strokeStyle = '#fbf3e0';
        g.lineWidth = 6;
        const m = 34;
        g.strokeRect(m, m, w - m * 2, h - m * 2);
        // halfway line & centre circle
        g.beginPath();
        g.moveTo(w / 2, m);
        g.lineTo(w / 2, h - m);
        g.stroke();
        g.beginPath();
        g.arc(w / 2, h / 2, 74, 0, Math.PI * 2);
        g.stroke();
        g.fillStyle = '#fbf3e0';
        g.beginPath();
        g.arc(w / 2, h / 2, 7, 0, Math.PI * 2);
        g.fill();
        // penalty boxes (left = Barbados, right = Grenada)
        const pbW = 148, pbH = 260, gbW = 54, gbH = 132;
        g.strokeRect(m, (h - pbH) / 2, pbW, pbH);
        g.strokeRect(m, (h - gbH) / 2, gbW, gbH);
        g.strokeRect(w - m - pbW, (h - pbH) / 2, pbW, pbH);
        g.strokeRect(w - m - gbW, (h - gbH) / 2, gbW, gbH);
        // penalty spots
        g.beginPath();
        g.arc(m + 102, h / 2, 6, 0, Math.PI * 2);
        g.arc(w - m - 102, h / 2, 6, 0, Math.PI * 2);
        g.fill();
      }),
    []
  );
}

/** Classic black-and-white soccer ball texture */
function useBallTex() {
  return useMemo(
    () =>
      makeCanvasTex(256, 128, (g, w, h) => {
        g.fillStyle = '#fdf9f6';
        g.fillRect(0, 0, w, h);
        g.fillStyle = INK;
        const pts: [number, number][] = [
          [32, 34], [96, 26], [160, 34], [224, 26],
          [64, 72], [128, 70], [192, 72],
          [32, 108], [112, 108], [192, 108],
        ];
        for (const [cx, cy] of pts) {
          g.beginPath();
          for (let i = 0; i < 5; i++) {
            const a = (i * Math.PI * 2) / 5 - Math.PI / 2;
            const x = cx + Math.cos(a) * 14;
            const y = cy + Math.sin(a) * 14;
            if (i === 0) g.moveTo(x, y);
            else g.lineTo(x, y);
          }
          g.closePath();
          g.fill();
        }
      }),
    []
  );
}

/** Dynamic scoreboard texture */
function useScoreTex(score: ScoreState) {
  return useMemo(
    () =>
      makeCanvasTex(512, 256, (g, w, h) => {
        g.fillStyle = '#241726';
        g.fillRect(0, 0, w, h);
        g.fillStyle = '#2e384d';
        g.fillRect(10, 10, w - 20, h - 20);
        // header strip
        g.fillStyle = score.highlight ? '#d0532f' : '#2f6f73';
        g.fillRect(10, 10, w - 20, 48);
        g.fillStyle = '#fbf3e0';
        g.font = 'bold 26px "Arial Black", Impact, sans-serif';
        g.textAlign = 'center';
        g.fillText(score.banner, w / 2, 43);
        // team boxes
        g.fillStyle = '#1e4ea8';
        g.fillRect(26, 76, 155, 118);
        g.fillStyle = '#c8432a';
        g.fillRect(w - 181, 76, 155, 118);
        g.fillStyle = '#f2b234';
        g.font = 'bold 30px "Arial Black", sans-serif';
        g.fillText('BAR', 103, 114);
        g.fillText('GRN', w - 103, 114);
        g.fillStyle = '#fdf9f6';
        g.font = 'bold 64px "Arial Black", sans-serif';
        g.fillText(String(score.bar), 103, 178);
        g.fillText(String(score.grn), w - 103, 178);
        // clock
        g.fillStyle = '#f2b234';
        g.font = 'bold 42px "Arial Black", sans-serif';
        g.fillText(score.clock, w / 2, 148);
        g.fillStyle = '#e8d8b0';
        g.font = 'bold 18px sans-serif';
        g.fillText('CARIBBEAN CUP \'94', w / 2, 224);
      }),
    [score.bar, score.grn, score.clock, score.banner, score.highlight]
  );
}

/** In-world Tournament Rulebook Sign */
function useRuleTex(scrapped: boolean) {
  return useMemo(
    () =>
      makeCanvasTex(512, 384, (g, w, h) => {
        g.fillStyle = '#241726';
        g.fillRect(0, 0, w, h);
        g.fillStyle = '#fbf3e0';
        g.fillRect(14, 14, w - 28, h - 28);
        g.fillStyle = '#2f6f73';
        g.fillRect(14, 14, w - 28, 68);
        g.fillStyle = '#fbf3e0';
        g.font = 'bold 32px "Arial Black", sans-serif';
        g.textAlign = 'center';
        g.fillText('OFFICIAL RULEBOOK', w / 2, 60);
        g.fillStyle = '#241726';
        g.font = 'bold 30px "Arial Black", sans-serif';
        g.fillText('TIED AFTER 90 MIN?', w / 2, 142);
        g.fillStyle = '#d0532f';
        g.font = 'bold 46px "Arial Black", sans-serif';
        g.fillText('GOLDEN GOAL', w / 2, 212);
        g.fillStyle = '#1e4ea8';
        g.font = 'bold 58px "Arial Black", sans-serif';
        g.fillText('= 2 GOALS!', w / 2, 286);
        g.fillStyle = '#6b5240';
        g.font = 'bold 22px sans-serif';
        g.fillText('+30 MIN EXTRA TIME', w / 2, 336);
        if (scrapped) {
          g.save();
          g.translate(w / 2, h / 2 + 12);
          g.rotate(-0.24);
          g.strokeStyle = '#c8231a';
          g.lineWidth = 14;
          g.strokeRect(-210, -56, 420, 112);
          g.fillStyle = 'rgba(200, 35, 26, 0.14)';
          g.fillRect(-210, -56, 420, 112);
          g.fillStyle = '#c8231a';
          g.font = 'bold 64px "Arial Black", sans-serif';
          g.fillText('SCRAPPED!', 0, 22);
          g.restore();
        }
      }),
    [scrapped]
  );
}

/** In-world Golden Jackpot Ticket Prop */
function useTicketTex() {
  return useMemo(
    () =>
      makeCanvasTex(512, 256, (g, w, h) => {
        g.fillStyle = '#241726';
        g.fillRect(0, 0, w, h);
        g.fillStyle = '#f2b234';
        g.fillRect(12, 12, w - 24, h - 24);
        g.strokeStyle = '#7a3b22';
        g.lineWidth = 6;
        g.strokeRect(26, 26, w - 52, h - 52);
        g.fillStyle = '#241726';
        g.textAlign = 'center';
        g.font = 'bold 34px "Arial Black", sans-serif';
        g.fillText('JACKPOT TICKET', w / 2, 92);
        g.fillStyle = '#c8432a';
        g.font = 'bold 50px "Arial Black", sans-serif';
        g.fillText('+30 MIN = x2', w / 2, 168);
        g.fillStyle = '#241726';
        g.font = 'bold 22px sans-serif';
        g.fillText('ONE GOAL WINS BY TWO', w / 2, 212);
      }),
    []
  );
}

function useBannerTex(label: string, bg: string, fg: string) {
  return useMemo(
    () =>
      makeCanvasTex(256, 64, (g, w, h) => {
        g.fillStyle = '#241726';
        g.fillRect(0, 0, w, h);
        g.fillStyle = bg;
        g.fillRect(4, 4, w - 8, h - 8);
        g.fillStyle = fg;
        g.font = 'bold 32px "Arial Black", sans-serif';
        g.textAlign = 'center';
        g.fillText(label, w / 2, 44);
      }),
    [label, bg, fg]
  );
}

/** One 3D soccer goal with tubular posts, crossbar, net, and team banner */
const Goal: React.FC<{x: number; side: 1 | -1; label: string; col: string; textCol: string}> = ({x, side, label, col, textCol}) => {
  const banner = useBannerTex(label, col, textCol);
  const w = 4.6, h = 2.15, d = 1.4;
  return (
    <group position={[x, 0, 0]}>
      {/* Posts & crossbar */}
      <mesh position={[0, h / 2, -w / 2]} castShadow>
        <cylinderGeometry args={[0.075, 0.075, h, 10]} />
        <meshToonMaterial color="#fdf9f6" gradientMap={LOOK_RAMP} />
      </mesh>
      <mesh position={[0, h / 2, w / 2]} castShadow>
        <cylinderGeometry args={[0.075, 0.075, h, 10]} />
        <meshToonMaterial color="#fdf9f6" gradientMap={LOOK_RAMP} />
      </mesh>
      <mesh position={[0, h, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <cylinderGeometry args={[0.075, 0.075, w + 0.14, 10]} />
        <meshToonMaterial color="#fdf9f6" gradientMap={LOOK_RAMP} />
      </mesh>
      {/* Back support frame */}
      <mesh position={[side * d, h / 2, -w / 2]}>
        <cylinderGeometry args={[0.05, 0.05, h, 8]} />
        <meshToonMaterial color="#e8d8b0" gradientMap={LOOK_RAMP} />
      </mesh>
      <mesh position={[side * d, h / 2, w / 2]}>
        <cylinderGeometry args={[0.05, 0.05, h, 8]} />
        <meshToonMaterial color="#e8d8b0" gradientMap={LOOK_RAMP} />
      </mesh>
      {/* Translucent toon net */}
      <mesh position={[side * d, h / 2, 0]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[w, h]} />
        <meshBasicMaterial color="#fbf3e0" transparent opacity={0.35} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[side * (d / 2), h, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[d, w]} />
        <meshBasicMaterial color="#fbf3e0" transparent opacity={0.3} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[side * (d / 2), h / 2, -w / 2]}>
        <planeGeometry args={[d, h]} />
        <meshBasicMaterial color="#fbf3e0" transparent opacity={0.3} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[side * (d / 2), h / 2, w / 2]}>
        <planeGeometry args={[d, h]} />
        <meshBasicMaterial color="#fbf3e0" transparent opacity={0.3} side={THREE.DoubleSide} />
      </mesh>
      {/* Team banner above net */}
      <mesh position={[side * 0.2, h + 0.55, 0]} rotation={[0, side < 0 ? Math.PI / 2 : -Math.PI / 2, 0]}>
        <boxGeometry args={[2.6, 0.62, 0.08]} />
        <meshBasicMaterial map={banner} />
      </mesh>
    </group>
  );
};

/** Tropical palm tree behind the Caribbean stadium stands */
const Palm: React.FC<{p: [number, number, number]}> = ({p}) => (
  <group position={p}>
    <mesh position={[0, 2.2, 0]} rotation={[0, 0, 0.08]} castShadow>
      <cylinderGeometry args={[0.16, 0.26, 4.4, 8]} />
      <meshToonMaterial color="#8a5a32" gradientMap={LOOK_RAMP} />
    </mesh>
    {[0, 1.1, 2.2, 3.3, 4.4, 5.4].map((a, i) => (
      <mesh key={i} position={[Math.cos(a) * 0.9, 4.3, Math.sin(a) * 0.9]} rotation={[0.45 * Math.sin(a), a, -0.45 * Math.cos(a)]}>
        <boxGeometry args={[1.9, 0.12, 0.45]} />
        <meshToonMaterial color={i % 2 === 0 ? '#2f8a52' : '#3fa062'} gradientMap={LOOK_RAMP} />
      </mesh>
    ))}
  </group>
);

export const Stadium: React.FC<{score: ScoreState; ball: BallState; boards?: StoryBoards}> = ({score, ball, boards}) => {
  const pitchTex = usePitchTex();
  const ballTex = useBallTex();
  const scoreTex = useScoreTex(score);
  const ruleTex = useRuleTex(Boolean(boards?.ruleboard?.scrapped));
  const ticketTex = useTicketTex();

  return (
    <group>
      {/* Surrounding stadium apron */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.04, 0]} receiveShadow>
        <planeGeometry args={[120, 120]} />
        <meshToonMaterial color="#d8c39a" gradientMap={LOOK_RAMP} />
      </mesh>
      {/* Main football pitch */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[32, 18]} />
        <meshToonMaterial map={pitchTex} gradientMap={LOOK_RAMP} />
      </mesh>

      {/* Left goal = Barbados, Right goal = Grenada */}
      <Goal x={-14.5} side={-1} label="BARBADOS" col="#1e4ea8" textCol="#f2b234" />
      <Goal x={14.5} side={1} label="GRENADA" col="#c8432a" textCol="#f2b234" />

      {/* Back grandstand bleachers (z = -11.8 to -15.2) */}
      {[0, 1, 2, 3].map((row) => (
        <mesh key={row} position={[0, 0.45 + row * 0.65, -11.6 - row * 0.95]} receiveShadow castShadow>
          <boxGeometry args={[34, 0.65, 0.95]} />
          <meshToonMaterial color={row % 2 === 0 ? '#e8d8b0' : '#d6c298'} gradientMap={LOOK_RAMP} />
        </mesh>
      ))}
      {/* Back wall behind bleachers */}
      <mesh position={[0, 2.2, -15.5]}>
        <boxGeometry args={[35, 4.4, 0.4]} />
        <meshToonMaterial color="#2f6f73" gradientMap={LOOK_RAMP} />
      </mesh>
      {/* Perimeter ad boards along back touchline */}
      <mesh position={[0, 0.45, -10.3]}>
        <boxGeometry args={[32, 0.9, 0.16]} />
        <meshToonMaterial color="#d0532f" gradientMap={LOOK_RAMP} />
      </mesh>

      {/* Dynamic elevated scoreboard */}
      <group position={[0, 4.5, -11.4]}>
        <mesh position={[-2.1, -1.8, 0]}>
          <cylinderGeometry args={[0.14, 0.14, 3.6, 8]} />
          <meshToonMaterial color="#3d4a66" gradientMap={LOOK_RAMP} />
        </mesh>
        <mesh position={[2.1, -1.8, 0]}>
          <cylinderGeometry args={[0.14, 0.14, 3.6, 8]} />
          <meshToonMaterial color="#3d4a66" gradientMap={LOOK_RAMP} />
        </mesh>
        <mesh castShadow>
          <boxGeometry args={[5.4, 2.7, 0.25]} />
          <meshBasicMaterial map={scoreTex} />
        </mesh>
      </group>

      {/* Floodlight towers & tropical palms */}
      {[-15.5, 15.5].map((x, i) => (
        <group key={i} position={[x, 0, -12.5]}>
          <mesh position={[0, 5.2, 0]}>
            <cylinderGeometry args={[0.16, 0.24, 10.4, 8]} />
            <meshToonMaterial color="#3d4a66" gradientMap={LOOK_RAMP} />
          </mesh>
          <mesh position={[0, 10.4, 0.3]}>
            <boxGeometry args={[2.2, 1.0, 0.4]} />
            <meshBasicMaterial color="#fbf3e0" />
          </mesh>
        </group>
      ))}
      <Palm p={[-18, 0, -13]} />
      <Palm p={[-12, 0, -16.5]} />
      <Palm p={[12, 0, -16.5]} />
      <Palm p={[18, 0, -13]} />

      {/* Hero Soccer Ball */}
      <mesh position={ball.p} rotation={[0, (ball.spin ?? 0) * 0.7, -(ball.spin ?? 0)]} scale={ball.scale ?? 1} castShadow>
        <sphereGeometry args={[0.24, 18, 14]} />
        <meshToonMaterial map={ballTex} gradientMap={LOOK_RAMP} />
      </mesh>

      {/* In-world Rulebook Sign (when active) */}
      {boards?.ruleboard && (
        <group position={boards.ruleboard.p} rotation={[0, boards.ruleboard.ry ?? 0, 0]} scale={boards.ruleboard.scale ?? 1}>
          <mesh position={[0, 0.65, 0]}>
            <cylinderGeometry args={[0.07, 0.09, 1.3, 8]} />
            <meshToonMaterial color="#6b5240" gradientMap={LOOK_RAMP} />
          </mesh>
          <mesh position={[0, 1.95, 0]} castShadow>
            <boxGeometry args={[2.2, 1.65, 0.12]} />
            <meshBasicMaterial map={ruleTex} />
          </mesh>
        </group>
      )}

      {/* In-world Golden Jackpot Ticket (when active) */}
      {boards?.ticket && (
        <group position={boards.ticket.p} rotation={[0, boards.ticket.ry ?? 0, 0]} scale={boards.ticket.scale ?? 1}>
          <mesh position={[0, 1.55, 0]} castShadow>
            <boxGeometry args={[2.1, 1.05, 0.1]} />
            <meshBasicMaterial map={ticketTex} />
          </mesh>
        </group>
      )}
    </group>
  );
};
